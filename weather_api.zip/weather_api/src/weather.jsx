import React, { useState } from 'react';

const Weather = () => {
  const [city, setCity] = useState('');
  const [weatherData, setWeatherData] = useState(null);
  const [error, setError] = useState('');

  const API_KEY = 'f31c95b6d0234122b08194514251202'; // My WeatherAPI key
  const baseURL = 'https://api.weatherapi.com/v1/current.json';

  const handleSearch = async () => {
    if (!city) return;

    try {
      const response = await fetch(`${baseURL}?key=${API_KEY}&q=${city}`);
      const data = await response.json();
      if (data.error) {
        setError('City not found');
        setWeatherData(null);
      } else {
        setWeatherData(data);
        setError('');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
      setWeatherData(null);
    }
  };

  return (
    <div>
      <h1>Weather App</h1>
      <input
        type="text"
        placeholder="Enter city name"
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      {weatherData && (
        <div>
          <h2>{weatherData.location.name}, {weatherData.location.country}</h2>
          <p>Temperature: {weatherData.current.temp_c}°C</p>
          <p>Condition: {weatherData.current.condition.text}</p>
          <img
            src={weatherData.current.condition.icon}
            alt={weatherData.current.condition.text}
          />
        </div>
      )}
    </div>
  );
};

export default Weather;
