import { useState } from 'react'
import Weather from './Weather';
import './App.css'

function App() {

  return (
    <div className="App">
      <Weather />
    </div>
  )
}

export default App
